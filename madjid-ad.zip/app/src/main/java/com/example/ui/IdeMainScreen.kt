package com.example.ui

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.core.adm.AdmDownloadEngine
import com.example.core.adm.DownloadStatus
import com.example.core.adm.DownloadTaskItem
import com.example.core.adm.SniffedMediaLink
import com.example.data.model.ThemeMode

enum class AdmTab {
    QUEUE,
    BROWSER_SNIFFER
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeMainScreen(viewModel: IdeViewModel) {
    val themeMode by viewModel.themeMode.collectAsState()
    val tasks by viewModel.downloadTasks.collectAsState()
    val sniffedLinks by viewModel.sniffedLinks.collectAsState()
    val isProbingUrl by viewModel.isProbingUrl.collectAsState()
    val browserCurrentUrl by viewModel.browserCurrentUrl.collectAsState()

    var activeTab by remember { mutableStateOf(AdmTab.QUEUE) }
    var filterState by remember { mutableStateOf("ALL") } // ALL, ACTIVE, COMPLETED
    var showAddUrlSheet by remember { mutableStateOf(false) }
    var newUrlInput by remember { mutableStateOf("") }
    var customFileNameInput by remember { mutableStateOf("") }
    var selectedSegmentCount by remember { mutableStateOf(16) }

    val totalLiveSpeed = tasks
        .filter { it.status == DownloadStatus.DOWNLOADING }
        .sumOf { it.totalSpeedBytesPerSec }

    val filteredTasks = remember(tasks, filterState) {
        when (filterState) {
            "ACTIVE" -> tasks.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PROBING || it.status == DownloadStatus.PAUSED }
            "COMPLETED" -> tasks.filter { it.status == DownloadStatus.COMPLETED }
            else -> tasks
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // ADM Iconic Triple-Arrow Badge
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(Color(0xFF0284C7), Color(0xFF00E676))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Download,
                                contentDescription = "ADM Icon",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "ADM Pro 16x Turbo",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${formatSpeed(totalLiveSpeed)} · حفظ في: Download/${AdmDownloadEngine.PUBLIC_FOLDER_NAME}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (totalLiveSpeed > 0) Color(0xFF00E676) else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                actions = {
                    // Add Direct Link Button
                    IconButton(onClick = { showAddUrlSheet = true }) {
                        Icon(
                            Icons.Default.AddLink,
                            contentDescription = "إضافة رابط جديد",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Theme Switcher: OLED / Light / Dark
                    FilledTonalButton(
                        onClick = { viewModel.toggleTheme() },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .padding(end = 6.dp)
                    ) {
                        val (icon, label) = when (themeMode) {
                            ThemeMode.OLED -> Icons.Default.Contrast to "OLED"
                            ThemeMode.LIGHT -> Icons.Default.LightMode to "نهاري"
                            ThemeMode.DARK -> Icons.Default.DarkMode to "ليلي"
                        }
                        Icon(icon, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            if (activeTab == AdmTab.QUEUE) {
                ExtendedFloatingActionButton(
                    onClick = { showAddUrlSheet = true },
                    containerColor = Color(0xFF0284C7),
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("تحميل سريع (16 جزء)", fontWeight = FontWeight.Bold) }
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Top Navigation Tabs: Queue vs Smart Browser Sniffer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { activeTab = AdmTab.QUEUE },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeTab == AdmTab.QUEUE) Color(0xFF0284C7) else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (activeTab == AdmTab.QUEUE) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("التحميلات (${tasks.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { activeTab = AdmTab.BROWSER_SNIFFER },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeTab == AdmTab.BROWSER_SNIFFER) Color(0xFF00C853) else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (activeTab == AdmTab.BROWSER_SNIFFER) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Icon(Icons.Default.TravelExplore, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "المتصفح الذكي (${sniffedLinks.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

            when (activeTab) {
                AdmTab.QUEUE -> {
                    // Filter Segmented Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                "ALL" to "الكل (${tasks.size})",
                                "ACTIVE" to "جاري التحميل",
                                "COMPLETED" to "مكتمل"
                            ).forEach { (key, title) ->
                                FilterChip(
                                    selected = filterState == key,
                                    onClick = { filterState = key },
                                    label = { Text(title, fontSize = 11.sp) }
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.resumeAllTasks() },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF00E676))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("استئناف الكل", fontSize = 10.sp)
                            }
                            OutlinedButton(
                                onClick = { viewModel.pauseAllTasks() },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFFFFB300))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("إيقاف الكل", fontSize = 10.sp)
                            }
                        }
                    }

                    if (filteredTasks.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    Icons.Default.CloudDownload,
                                    contentDescription = null,
                                    modifier = Modifier.size(54.dp),
                                    tint = Color(0xFF0284C7)
                                )
                                Text(
                                    text = "لا توجد مهام تحميل حالياً",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "اضغط على زر التحميل السريع لإضافة رابط وتقسيمه إلى 16 جزءاً متوازياً أو افتح المتصفح الذكي لالتقاط الروابط المباشرة.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 88.dp)
                        ) {
                            items(filteredTasks, key = { it.id }) { task ->
                                AdmDownloadTaskCard(
                                    task = task,
                                    onPause = { viewModel.pauseTask(task.id) },
                                    onResume = { viewModel.resumeTask(task.id) },
                                    onDelete = { viewModel.deleteTask(task.id) }
                                )
                            }
                        }
                    }
                }

                AdmTab.BROWSER_SNIFFER -> {
                    SmartBrowserSnifferSection(
                        currentUrl = browserCurrentUrl,
                        isProbing = isProbingUrl,
                        sniffedLinks = sniffedLinks,
                        onNavigateAndSniff = { url -> viewModel.analyzeAndSniffUrl(url) },
                        onResourceSniffed = { url, title -> viewModel.onWebViewResourceSniffed(url, title) },
                        onDownloadSniffed = { link ->
                            viewModel.startNewDownload(link.url, link.fileName, 16)
                            activeTab = AdmTab.QUEUE
                        },
                        onClearSniffed = { viewModel.clearSniffed() }
                    )
                }
            }
        }
    }

    // Add New 16-Part Download Dialog
    if (showAddUrlSheet) {
        AlertDialog(
            onDismissRequest = { showAddUrlSheet = false },
            title = {
                Text(
                    text = "تحميل فائق السرعة (تقسيم 16 جزء)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newUrlInput,
                        onValueChange = { newUrlInput = it },
                        label = { Text("رابط الصفحة أو الرابط المباشر (URL)", fontSize = 12.sp) },
                        placeholder = { Text("https://example.com/file.mp4", fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = customFileNameInput,
                        onValueChange = { customFileNameInput = it },
                        label = { Text("اسم الملف (اختياري - يتم اكتشافه تلقائياً)", fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "مجلد الحفظ المباشر: /storage/emulated/0/Download/${AdmDownloadEngine.PUBLIC_FOLDER_NAME}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00E676)
                    )

                    Text(
                        text = "عدد الأجزاء المتوازية: $selectedSegmentCount جزء",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(4, 8, 16).forEach { count ->
                            FilterChip(
                                selected = selectedSegmentCount == count,
                                onClick = { selectedSegmentCount = count },
                                label = { Text("$count جزء", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newUrlInput.isNotBlank()) {
                            viewModel.startNewDownload(
                                newUrlInput.trim(),
                                customFileNameInput.trim().ifEmpty { null },
                                selectedSegmentCount
                            )
                            newUrlInput = ""
                            customFileNameInput = ""
                            showAddUrlSheet = false
                            activeTab = AdmTab.QUEUE
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text("بدء التحميل (16x)", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddUrlSheet = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun AdmDownloadTaskCard(
    task: DownloadTaskItem,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onDelete: () -> Unit
) {
    var showAll16Details by remember { mutableStateOf(true) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(12.dp)
            ),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Header: File Name + Live Speed & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.fileName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${formatBytesUi(task.totalDownloadedBytes)} / ${formatBytesUi(task.totalBytes)} · ${(task.overallProgress * 100).toInt()}% · ${task.segmentCount} أجزاء · يدعم الاستئناف الذكي (256KB Buffer)",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Live Speed Readout
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = when (task.status) {
                                DownloadStatus.DOWNLOADING -> formatSpeed(task.totalSpeedBytesPerSec)
                                DownloadStatus.COMPLETED -> "مكتمل 100%"
                                DownloadStatus.PAUSED -> "متوقف مؤقتاً"
                                DownloadStatus.PROBING -> "فحص الرابط..."
                                DownloadStatus.FAILED -> "خطأ اتصال"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            color = when (task.status) {
                                DownloadStatus.DOWNLOADING -> Color(0xFF00E676)
                                DownloadStatus.COMPLETED -> Color(0xFF38BDF8)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        if (task.status == DownloadStatus.DOWNLOADING && task.etaSeconds > 0) {
                            Text(
                                text = "المتبقي: ${task.etaSeconds} ث",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (task.status == DownloadStatus.DOWNLOADING || task.status == DownloadStatus.PROBING) {
                        IconButton(onClick = onPause, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.PauseCircle, contentDescription = "Pause", tint = Color(0xFFFFB300))
                        }
                    } else if (task.status == DownloadStatus.PAUSED || task.status == DownloadStatus.FAILED) {
                        IconButton(onClick = onResume, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.PlayCircle, contentDescription = "Resume", tint = Color(0xFF00E676))
                        }
                    }

                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 2. Unified 16-Part Harmonious Multi-Color Ribbon Bar
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    horizontalArrangement = Arrangement.spacedBy(1.5.dp)
                ) {
                    task.segments.forEach { seg ->
                        val segColor = Color(seg.colorHex)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .background(segColor.copy(alpha = 0.16f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(seg.progressFraction)
                                    .fillMaxHeight()
                                    .background(segColor)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAll16Details = !showAll16Details },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مسار الحفظ: Download/${AdmDownloadEngine.PUBLIC_FOLDER_NAME}/${task.fileName}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00E676),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = if (showAll16Details) "إخفاء الأجزاء ▲" else "عرض الـ 16 جزء ▼",
                        fontSize = 10.sp,
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // 3. Detailed 16-Segment Grid (4x4 / 2x8) with each part's individual color & progress
            AnimatedVisibility(visible = showAll16Details) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    task.segments.chunked(4).forEach { rowSegments ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            rowSegments.forEach { seg ->
                                val partColor = Color(seg.colorHex)
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                                        .padding(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(7.dp)
                                                    .clip(CircleShape)
                                                    .background(partColor)
                                            )
                                            Text(
                                                text = "#${seg.index + 1}",
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text(
                                            text = "${(seg.progressFraction * 100).toInt()}%",
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = partColor
                                        )
                                    }

                                    // Individual Segment Colored Bar
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(partColor.copy(alpha = 0.2f))
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth(seg.progressFraction)
                                                .fillMaxHeight()
                                                .background(partColor)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SmartBrowserSnifferSection(
    currentUrl: String,
    isProbing: Boolean,
    sniffedLinks: List<SniffedMediaLink>,
    onNavigateAndSniff: (String) -> Unit,
    onResourceSniffed: (String, String?) -> Unit,
    onDownloadSniffed: (SniffedMediaLink) -> Unit,
    onClearSniffed: () -> Unit
) {
    var addressInput by remember(currentUrl) { mutableStateOf(currentUrl) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Smart Browser Address Bar + Sniff Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = addressInput,
                onValueChange = { addressInput = it },
                placeholder = { Text("أدخل رابط موقع أو صفحة فيديو لاستخراج الرابط المباشر...", fontSize = 12.sp) },
                singleLine = true,
                modifier = Modifier.weight(1f),
                textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            )

            Button(
                onClick = { onNavigateAndSniff(addressInput) },
                enabled = !isProbing,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
            ) {
                if (isProbing) {
                    CircularProgressIndicator(modifier = Modifier.size(15.dp), strokeWidth = 2.dp, color = Color.Black)
                } else {
                    Icon(Icons.Default.Radar, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("كشف الروابط", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Discovered Direct Links Drawer / List
        if (sniffedLinks.isNotEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الروابط المباشرة المكتشفة ذكياً (${sniffedLinks.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF00E676)
                        )
                        TextButton(onClick = onClearSniffed) {
                            Text("مسح", fontSize = 11.sp)
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.heightIn(max = 170.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(sniffedLinks) { link ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = link.fileName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${link.typeLabel} · ${link.sizeEstimate} · ${link.sourceTag}",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Button(
                                    onClick = { onDownloadSniffed(link) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تحميل 16x", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Embedded Android WebView with Resource Interceptor Sniffer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        setDownloadListener { url, _, contentDisposition, mimetype, _ ->
                            onResourceSniffed(url, contentDisposition ?: mimetype)
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString()
                                if (reqUrl != null) {
                                    onResourceSniffed(reqUrl, null)
                                }
                                return super.shouldInterceptRequest(view, request)
                            }
                        }
                        loadUrl(currentUrl)
                    }
                },
                update = { webView ->
                    if (webView.url != currentUrl && currentUrl.isNotBlank()) {
                        webView.loadUrl(currentUrl)
                    }
                }
            )
        }
    }
}

private fun formatBytesUi(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format("%.2f GB", gb)
        mb >= 1.0 -> String.format("%.2f MB", mb)
        kb >= 1.0 -> String.format("%.1f KB", kb)
        else -> "$bytes B"
    }
}

private fun formatSpeed(bytesPerSec: Long): String {
    if (bytesPerSec <= 0L) return "0 KB/s"
    val kb = bytesPerSec / 1024.0
    val mb = kb / 1024.0
    return if (mb >= 1.0) {
        String.format("%.2f MB/s", mb)
    } else {
        String.format("%.1f KB/s", kb)
    }
}
